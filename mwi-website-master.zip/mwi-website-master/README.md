# mwi-website
This is the website source code for [Mountaineer Wood Industries](http://mountaineerwoodindustries.com/).

Built with [yeoman](http://yeoman.io/), [bower](http://bower.io/), [Twitter Bootstrap](http://getbootstrap.com/), [gruntjs](http://gruntjs.com/), [Lightbox 2](http://lokeshdhakar.com/projects/lightbox2/), and [modernizr.js](http://modernizr.com/)
